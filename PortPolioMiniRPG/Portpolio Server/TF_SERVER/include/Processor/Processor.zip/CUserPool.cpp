#include "CUserPool.h"
#include "../Object/User.h"


CUserPool::CUserPool() :specialID(NUM_OF_NPC)
{
}

CUserPool::~CUserPool()
{
}

void CUserPool::Initialize()
{
	specialID = NUM_OF_NPC;

	for (short i = 0; i < MAX_USER; ++i) {
		indexQueue.push(i);
		userPool.emplace_back(new CUser());
	}

	XMFLOAT3  StartPoint = XMFLOAT3(60.f, 0.f, -60.f);
	for (int i = 0; i < MAX_USER; ++i)
	{
		userPool[i]->SetPos(StartPoint);
		userPool[i]->SetOOBB(StartPoint);
		userPool[i]->SetStage(STAGE::STAGE1);
		userPool[i]->SetCurCharacter(CHARACTER::WARRIOR);
		userPool[i]->SetHP(500.f);
		userPool[i]->SetMP(500.f);
		userPool[i]->SetAtk(10.f);
	}
}

void CUserPool::Finalize()
{
	Safe_Delete_VecList(userPool);
}

void CUserPool::AddUserHashMap(short index)
{
	IDHasher::accessor Acc;
	if (hashMap.insert(Acc, specialID))
	{
		Acc->second = index;
		Acc.release();
	}
	++specialID;
}

short CUserPool::GetAvailableIndex()
{
	short TempIndex;
	if (false == indexQueue.empty()) {
		if (indexQueue.try_pop(TempIndex))
			return TempIndex;
	}
	return -1;
}

CUser& CUserPool::GetUser(short id)
{
	IDHasher::const_accessor CAcc;
	//O(1)�� �ð� �ҿ��� 
	if (hashMap.find(CAcc, id)){
		return *userPool[CAcc->second];
	}
}
