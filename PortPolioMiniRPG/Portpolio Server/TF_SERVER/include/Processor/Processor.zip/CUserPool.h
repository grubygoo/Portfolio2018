#pragma once
#include "../Include.h"
class CUserPool
{
	typedef tbb::concurrent_hash_map<short, short> IDHasher;
    typedef	tbb::concurrent_queue<short> FreeIndex;

public:
	CUserPool();
	~CUserPool();

	void Initialize();
	void Finalize();
	void AddUserHashMap(short index);
	void RemoveUserHashMap(short index);
	short GetAvailableIndex();
	CUser& GetUser(short index);

private:
	std::vector<class CUser*> userPool;
	std::atomic<short> specialID;
	IDHasher hashMap;
	FreeIndex indexQueue;
};

